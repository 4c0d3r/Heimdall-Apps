<?php namespace App\SupportedApps\YourSpotify;

class YourSpotify extends \App\SupportedApps {

}