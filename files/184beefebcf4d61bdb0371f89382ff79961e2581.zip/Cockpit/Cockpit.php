<?php namespace App\SupportedApps\Cockpit;

class Cockpit extends \App\SupportedApps {

}