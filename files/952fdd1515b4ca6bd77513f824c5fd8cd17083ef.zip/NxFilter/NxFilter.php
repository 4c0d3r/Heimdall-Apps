<?php namespace App\SupportedApps\NxFilter;

class NxFilter extends \App\SupportedApps {

}