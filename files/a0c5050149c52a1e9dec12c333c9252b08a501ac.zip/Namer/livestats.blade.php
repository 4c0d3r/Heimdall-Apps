<ul class="livestats">
    <li>
        <span class="title">Failed</span>
        <strong>{!! $failed !!}</strong>
    </li>
    <li>
        <span class="title">Queued</span>
        <strong>{!! $queued !!}</strong>
    </li>
</ul>
