<?php namespace App\SupportedApps\SOGo;

class SOGo extends \App\SupportedApps {

}