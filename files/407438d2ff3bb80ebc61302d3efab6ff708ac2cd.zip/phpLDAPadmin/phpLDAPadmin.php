<?php namespace App\SupportedApps\phpLDAPadmin;

class phpLDAPadmin extends \App\SupportedApps {

}