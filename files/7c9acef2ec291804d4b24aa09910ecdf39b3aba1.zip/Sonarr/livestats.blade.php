<ul class="livestats">
    <li>
        <span class="title">Missing</span>
        <strong>{!! $missing !!}</strong>
    </li>
    <li>
        <span class="title">Queue</span>
        <strong>{!! $queue !!}</strong>
    </li>
</ul>
