<?php namespace App\SupportedApps\MusicBrainz;

class MusicBrainz extends \App\SupportedApps {

}